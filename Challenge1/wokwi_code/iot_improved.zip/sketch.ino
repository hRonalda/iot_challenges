#include <WiFi.h>
#include <esp_now.h>
#include "esp_sleep.h"

#define PIR_PIN 13
#define LIGHT_PIN 34

// ===== Simulator cycle period (8s) =====
#define PERIOD_MS 8000UL
#define MAX_RUNS 16

uint8_t broadcastAddress[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
esp_now_peer_info_t peerInfo;

// ===== Timing (us) =====
unsigned long SENSOR_READ_Time_us = 0;
unsigned long MESSAGE_BUILD_Time_us = 0;
unsigned long WIFI_ON_Time_us = 0;
unsigned long TRANSMISSION_Time_us = 0;
unsigned long WIFI_OFF_Time_us = 0;

// ===== ESP-NOW send callback =====
volatile bool sendDone = false;
volatile unsigned long tx_end_us = 0;
unsigned long tx_start_us = 0;

// ===== In simulator (no deep sleep), use normal globals so state persists =====
int runCount = 0;
int lastMotion = -1;   // 0/1
int lastLevel  = -1;   // 0..4

unsigned long lastCycleMs = 0;

void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  tx_end_us = micros();
  sendDone = true;
}

float getLightLux() {
  int analogValue = analogRead(LIGHT_PIN);
  if (analogValue < 1) analogValue = 1;
  if (analogValue > 4095) analogValue = 4095;

  float voltage = analogValue / 4095.0 * 3.3;
  if (voltage < 0.01) voltage = 0.01;

  float resistance = 2000 * voltage / (1.0 - voltage / 3.3);
  float lux = pow(50 * 1000 * pow(10, 0.7) / resistance, (1.0 / 0.7));
  if (lux < 0) lux = 0;
  return lux;
}

// Lux -> category level (0..4) for ~0..100000 lux
int luxToLevel(float lux) {
  if (lux < 50.0) return 0;         // Night
  if (lux < 300.0) return 1;        // Indoor dim
  if (lux < 2000.0) return 2;       // Indoor bright / shade
  if (lux < 20000.0) return 3;      // Outdoor / bright
  return 4;                         // Sunlight
}

const char* levelName(int level) {
  switch (level) {
    case 0: return "L0_NIGHT";
    case 1: return "L1_DIM";
    case 2: return "L2_INDOOR";
    case 3: return "L3_OUTDOOR";
    case 4: return "L4_SUN";
    default: return "L?_UNK";
  }
}

bool initEspNow() {
  WiFi.mode(WIFI_STA);

  if (esp_now_init() != ESP_OK) return false;

  esp_now_register_send_cb(OnDataSent);

  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;
  peerInfo.encrypt = false;

  if (esp_now_add_peer(&peerInfo) != ESP_OK) return false;

  return true;
}

void doOneCycle() {
  unsigned long t0, t1;

  runCount++;
  Serial.println();
  Serial.print("========== Run ");
  Serial.print(runCount);
  Serial.println(" ==========");

  if (runCount > MAX_RUNS) {
    Serial.println("Reached MAX_RUNS. Stop.");
    while (true) delay(1000);
  }

  // ===== SENSOR READ =====
  int motionNow;
  float lux;
  int luxInt;
  int levelNow;

  t0 = micros();
  motionNow = digitalRead(PIR_PIN);   // 0/1
  lux = getLightLux();
  luxInt = (int)lux;
  levelNow = luxToLevel(lux);
  t1 = micros();
  SENSOR_READ_Time_us = t1 - t0;

  // ===== Decide whether to send (send-on-change) =====
  bool motionChanged = (lastMotion == -1) ? true : (motionNow != lastMotion);
  bool levelChanged  = (lastLevel  == -1) ? true : (levelNow  != lastLevel);
  bool needSend = motionChanged || levelChanged;

  // Reset timing fields for this cycle
  MESSAGE_BUILD_Time_us = 0;
  WIFI_ON_Time_us = 0;
  TRANSMISSION_Time_us = 0;
  WIFI_OFF_Time_us = 0;

  String message;
  bool ok = false;

  if (needSend) {
    // ===== MESSAGE BUILD =====
    t0 = micros();
    String motionStr = (motionNow == HIGH) ? "MOTION_DETECTED" : "MOTION_NOT_DETECTED";
    message = motionStr + "-LEVEL:" + String(levelNow) + "-LUX:" + String(luxInt);
    t1 = micros();
    MESSAGE_BUILD_Time_us = t1 - t0;

    // ===== WIFI ON / ESP-NOW INIT =====
    t0 = micros();
    ok = initEspNow();
    t1 = micros();
    WIFI_ON_Time_us = t1 - t0;

    // ===== TRANSMISSION =====
    if (ok) {
      sendDone = false;
      tx_start_us = micros();

      esp_err_t result = esp_now_send(broadcastAddress, (uint8_t*)message.c_str(), message.length() + 1);

      if (result == ESP_OK) {
        while (!sendDone) delay(1);
        TRANSMISSION_Time_us = tx_end_us - tx_start_us;
      } else {
        TRANSMISSION_Time_us = 0;
      }
    }

    // ===== WIFI OFF =====
    t0 = micros();
    esp_now_deinit();
    WiFi.mode(WIFI_OFF);
    t1 = micros();
    WIFI_OFF_Time_us = t1 - t0;

    // Update last state only when we attempted to send
    lastMotion = motionNow;
    lastLevel = levelNow;
  } else {
    WiFi.mode(WIFI_OFF);
  }

  // ===== Print output =====
  Serial.println();
  Serial.print("MotionNow: ");
  Serial.print(motionNow);
  Serial.print(" | Lux: ");
  Serial.print(lux, 2);
  Serial.print(" | LevelNow: ");
  Serial.print(levelNow);
  Serial.print(" (");
  Serial.print(levelName(levelNow));
  Serial.println(")");

  Serial.print("LastMotion: ");
  Serial.print(lastMotion);
  Serial.print(" | LastLevel: ");
  Serial.println(lastLevel);

  Serial.print("needSend: ");
  Serial.print(needSend ? "YES" : "NO");
  Serial.print(" | motionChanged: ");
  Serial.print(motionChanged ? "YES" : "NO");
  Serial.print(" | levelChanged: ");
  Serial.println(levelChanged ? "YES" : "NO");

  Serial.print("Sensor Read Time: ");
  Serial.print(SENSOR_READ_Time_us);
  Serial.println(" us");

  if (needSend) {
    Serial.print("Message Build Time: ");
    Serial.print(MESSAGE_BUILD_Time_us);
    Serial.println(" us");

    Serial.print("WiFi ON Time: ");
    Serial.print(WIFI_ON_Time_us / 1000.0, 3);
    Serial.println(" ms");

    Serial.print("Transmission Time: ");
    Serial.print(TRANSMISSION_Time_us);
    Serial.println(" us");

    Serial.print("WiFi OFF Time: ");
    Serial.print(WIFI_OFF_Time_us);
    Serial.println(" us");

    Serial.print("Sent: ");
    Serial.println(message);
  } else {
    Serial.println("SKIP TX: no meaningful change (WiFi stayed OFF).");
  }

  unsigned long active_us_without_boot =
      SENSOR_READ_Time_us +
      MESSAGE_BUILD_Time_us +
      WIFI_ON_Time_us +
      TRANSMISSION_Time_us +
      WIFI_OFF_Time_us;

  float active_ms_without_boot = active_us_without_boot / 1000.0;
  float cycle_ms_without_boot = active_ms_without_boot + (float)PERIOD_MS;

  Serial.print("Total Active Time (sim cycle, no deep sleep): ");
  Serial.print(active_ms_without_boot, 3);
  Serial.println(" ms");

  Serial.print("Cycle Period (sim): ");
  Serial.print(cycle_ms_without_boot, 3);
  Serial.println(" ms");
}

void setup() {
  Serial.begin(115200);
  delay(300);

  pinMode(PIR_PIN, INPUT);
  pinMode(LIGHT_PIN, INPUT);

  WiFi.mode(WIFI_OFF);

  Serial.println("SIM MODE: periodic loop every 8s (no deep sleep).");
  Serial.println("Tip: keep lux/motion stable -> you should see SKIP TX after first run.");
}

void loop() {
  unsigned long now = millis();
  if (now - lastCycleMs >= PERIOD_MS) {
    lastCycleMs = now;
    doOneCycle();
  }
  delay(5);
}