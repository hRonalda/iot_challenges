#include <WiFi.h>
#include <esp_now.h>
#include "esp_sleep.h"

#define PIR_PIN 13
#define LIGHT_PIN 34

#define DEEP_SLEEP_TIME_US 4000000ULL

#define MAX_RUNS 16

uint8_t broadcastAddress[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
esp_now_peer_info_t peerInfo;

unsigned long SENSOR_READ_Time_us = 0;
unsigned long MESSAGE_BUILD_Time_us = 0;
unsigned long WIFI_ON_Time_us = 0;
unsigned long TRANSMISSION_Time_us = 0;
unsigned long WIFI_OFF_Time_us = 0;

volatile bool sendDone = false;
volatile unsigned long tx_end_us = 0;
unsigned long tx_start_us = 0;

RTC_DATA_ATTR int runCount = 0;

void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  tx_end_us = micros();
  sendDone = true;
}

String getMotionStatus() {
  return digitalRead(PIR_PIN) == HIGH ? "MOTION_DETECTED" : "MOTION_NOT_DETECTED";
}

float getLightLux() {
  int analogValue = analogRead(LIGHT_PIN);
  if (analogValue < 1) analogValue = 1;
  if (analogValue > 4095) analogValue = 4095;

  float voltage = analogValue / 4095.0 * 3.3;
  if (voltage < 0.01) voltage = 0.01;

  float resistance = 2000 * voltage / (1.0 - voltage / 3.3);
  float lux = pow(50 * 1000 * pow(10, 0.7) / resistance, (1.0 / 0.7));
  if (lux < 0) lux = 0;
  return lux;
}

bool initEspNow() {
  WiFi.mode(WIFI_STA);

  if (esp_now_init() != ESP_OK) {
    return false;
  }

  esp_now_register_send_cb(OnDataSent);

  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;
  peerInfo.encrypt = false;

  if (esp_now_add_peer(&peerInfo) != ESP_OK) {
    return false;
  }

  return true;
}

void setup() {
  unsigned long t0, t1;
 
  Serial.begin(115200);
  delay(300);

  runCount++;

  Serial.println();
  Serial.print("========== Run ");
  Serial.print(runCount);
  Serial.println(" ==========");

  // if already reached 16 runs, stop
  if (runCount > MAX_RUNS) {
    Serial.println("Reached 10 runs. Stop.");
    while (true) {
      delay(1000);
    }
  }

  pinMode(PIR_PIN, INPUT);
  pinMode(LIGHT_PIN, INPUT);

  // --> SENSOR READ  
  String motion;
  float lux;
  int luxInt;

  t0 = micros();
  motion = getMotionStatus();
  lux = getLightLux();
  luxInt = (int)lux;
  t1 = micros();
  SENSOR_READ_Time_us = t1 - t0;

  // --> MESSAGE BUILD
  String message;

  t0 = micros();
  message = motion + "-LUMINOSITY:" + String(luxInt);
  t1 = micros();
  MESSAGE_BUILD_Time_us = t1 - t0;

  // --> WIFI ON
  t0 = micros();
  bool ok = initEspNow();
  t1 = micros();
  WIFI_ON_Time_us = t1 - t0;

  // --> TRANSMISSION
  if (ok) {
    sendDone = false;
    tx_start_us = micros();

    esp_err_t result = esp_now_send(broadcastAddress, (uint8_t*)message.c_str(), message.length() + 1);

    if (result == ESP_OK) {
      while (!sendDone) {
        delay(1);
      }
      TRANSMISSION_Time_us = tx_end_us - tx_start_us;
    } else {
      TRANSMISSION_Time_us = 0;
    }
  } else {
    TRANSMISSION_Time_us = 0;
  }

  // -->  WIFI OFF 
  t0 = micros();
  esp_now_deinit();
  WiFi.mode(WIFI_OFF);
  t1 = micros();
  WIFI_OFF_Time_us = t1 - t0;

  // print the time
  unsigned long active_us_without_boot =
      SENSOR_READ_Time_us +
      MESSAGE_BUILD_Time_us +
      WIFI_ON_Time_us +
      TRANSMISSION_Time_us +
      WIFI_OFF_Time_us;

  float active_ms_without_boot = active_us_without_boot / 1000.0;
  float cycle_ms_without_boot = active_ms_without_boot + DEEP_SLEEP_TIME_US / 1000.0;

  Serial.println();

  Serial.print("Motion: ");
  Serial.print(digitalRead(PIR_PIN));
  Serial.print(" | Lux: ");
  Serial.println(lux, 2);

  Serial.print("Sensor Read Time: ");
  Serial.print(SENSOR_READ_Time_us);
  Serial.println(" microseconds");

  Serial.print("Message Build Time: ");
  Serial.print(MESSAGE_BUILD_Time_us);
  Serial.println(" microseconds");

  Serial.print("Transmission Time: ");
  Serial.print(TRANSMISSION_Time_us);
  Serial.println(" microseconds");

  Serial.print("Sent: ");
  Serial.println(message);

  Serial.print("WiFi ON Time: ");
  Serial.print(WIFI_ON_Time_us / 1000.0, 3);
  Serial.println(" ms");

  Serial.print("WiFi OFF Time: ");
  Serial.print(WIFI_OFF_Time_us);
  Serial.println(" microseconds");

  Serial.print("Total Active Time without BOOT: ");
  Serial.print(active_ms_without_boot, 3);
  Serial.println(" ms");

  Serial.print("Cycle Period without BOOT: ");
  Serial.print(cycle_ms_without_boot, 3);
  Serial.println(" ms");

  // Serial.println("Entering deep sleep...");
  // Serial.flush();

  // esp_sleep_enable_timer_wakeup(DEEP_SLEEP_TIME_US);
  // esp_deep_sleep_start();
  
  if (runCount < MAX_RUNS) {
    Serial.println("Entering deep sleep...");
    Serial.flush();
    esp_sleep_enable_timer_wakeup(DEEP_SLEEP_TIME_US);
    esp_deep_sleep_start();
  } else {
    Serial.println("Finished 10 runs.");
    while (true) {
      delay(1000);
    }
  }
}

void loop() {
}